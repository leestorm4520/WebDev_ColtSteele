# franc-cli

> CLI to detect the language of text.

View the [monorepo](https://github.com/wooorm/franc) for more packages
and usage information.

## Install

This package is [ESM only](https://gist.github.com/sindresorhus/a39789f98801d908bbc7ff3ecc99d99c):
Node 12+ is needed to use it.

npm:

```sh
npm install franc-cli --global
```

## License

[MIT](https://github.com/wooorm/franc/blob/franc/license) © [Titus Wormer](http://wooorm.com)
